# Guide d'utilisation — Fitness & Nutrition OS

Tout ce qu'il faut savoir pour installer l'application sur ton iPhone et ton ordinateur, l'utiliser au quotidien, et synchroniser les deux.

---

## 1. Télécharger les fichiers

Le plus simple : télécharge **`fitness-os.zip`** depuis cette conversation, puis décompresse-le. Tu obtiens un dossier `fitness-os` contenant :

```
index.html            l'application
tailwind.css          les styles
chart.umd.js          les graphiques
polices/              la police (3 fichiers)
manifest.webmanifest  le nom et les icônes de l'app
sw.js                 le fonctionnement hors ligne
icone-*.png           les icônes de l'écran d'accueil
```

Garde tous ces fichiers **ensemble**, sans les renommer. L'application ne dépend d'aucun service extérieur : elle fonctionne sans connexion dès la première ouverture.

**Essai immédiat sur ordinateur :** double-clique sur `index.html`. Tout marche, sauf l'installation et le mode hors ligne, qui exigent une vraie adresse web. C'est l'objet de l'étape suivante.

---

## 2. Mettre l'application en ligne (une seule fois, 10 minutes)

Pour l'installer sur ton iPhone, les fichiers doivent être servis en `https://`. GitHub Pages le fait gratuitement.

1. Crée un compte sur [github.com](https://github.com).
2. Clique sur **+ → New repository**. Nomme-le `fitness-os`, coche **Public**, puis **Create repository**.
3. Sur la page du dépôt : **Add file → Upload files**. Glisse **tous** les fichiers décompressés, dossier `polices` compris. Descends et clique **Commit changes**.
4. Onglet **Settings → Pages**. Sous *Source*, choisis **Deploy from a branch**, branche `main`, dossier `/ (root)`, puis **Save**.
5. Attends une minute et recharge : ton adresse apparaît, du type `https://tonpseudo.github.io/fitness-os/`.

Note-la, c'est elle que tu ouvriras sur tes deux appareils.

> Le code est public, pas tes données : elles restent dans le navigateur de chaque appareil.

**Mettre à jour plus tard :** re-téléverse le nouveau `index.html` par-dessus l'ancien. À la prochaine ouverture, l'application détecte la nouvelle version et propose « Recharger ». Tes données ne sont jamais touchées.

---

## 3. Installer sur l'iPhone

1. Ouvre ton adresse **dans Safari** (indispensable : Chrome iOS ne sait pas installer).
2. Touche le bouton **Partager** (le carré avec une flèche vers le haut).
3. Fais défiler, touche **Sur l'écran d'accueil**, puis **Ajouter**.
4. L'icône « Fitness OS » apparaît sur ton écran. Lancée depuis là, l'application s'ouvre en plein écran, sans barre d'adresse, et fonctionne **sans réseau**.

Pour vérifier : active le mode avion, puis ouvre l'application. Tout doit s'afficher normalement.

**Appui long sur l'icône** : raccourcis vers ta séance du jour, ta liste de courses ou ton planning.

---

## 4. Installer sur l'ordinateur

Avec **Chrome** ou **Edge** :

1. Ouvre ton adresse.
2. Dans la barre d'adresse, clique sur l'icône d'installation (un écran avec une flèche), ou menu **⋮ → Installer Fitness OS**.
3. L'application s'ouvre dans sa propre fenêtre et apparaît dans ton menu Démarrer ou ton Dock.

L'onglet **Profil** propose aussi un bouton « Installer sur cet appareil » quand ton navigateur le permet.

Avec **Firefox** ou **Safari sur Mac**, l'installation n'existe pas : ajoute simplement l'adresse aux favoris, tout fonctionne pareil.

---

## 5. Premiers réglages (10 minutes, une fois)

1. **Profil** : sexe, âge, taille, poids actuel, poids cible, niveau d'activité et rythme de prise de masse. Ton objectif calorique et tes macros se calculent aussitôt.
2. **Profil → Calories des jours d'entraînement** : ajuste le supplément des jours de musculation et de course, ou désactive-le.
3. **Training Planner → Constructeur de séance** : la semaine type est déjà remplie (6 séances plus une sortie course). Renomme, ajoute ou retire des exercices, jour par jour. Le bouton « Créer un exercice » ajoute les tiens.
4. **Meal Planner → Recettes** : 90 recettes sont fournies. Touche le nom d'une recette pour ouvrir sa fiche (macros, ingrédients, préparation, minuteurs), et « Modifier » pour ajuster quantités, prix et valeurs nutritionnelles.
5. **Meal Planner → Planning** : choisis tes jours de cuisine (mercredi et dimanche par défaut), puis clique sur **Proposer une semaine**.
6. **Stock** : saisis ce que tu as déjà chez toi, avec un seuil de réapprovisionnement pour les basiques (huile, riz, whey).

---

## 6. Une semaine type

**Chaque matin.** Profil : saisis ton poids. La courbe compare ta progression réelle à la prévision.

**À chaque repas.** Accueil : la carte « Aujourd'hui » liste tes quatre repas. Dans le planning, le bouton ✓ d'un repas le marque comme consommé et **déduit les quantités de ton stock**.

**En salle.** Training Planner → Mes séances → **Mode séance**. Un exercice à la fois, de gros champs pour le poids et les répétitions, un bouton ✓ par série qui lance le repos automatiquement. L'écran reste allumé. Tu peux aussi démarrer la séance depuis l'accueil.

**Avant les courses.** Meal Planner → Courses. La liste ne contient que ce qui manque, stock déduit, groupée par rayon avec les conditionnements et le budget. « Copier la liste » l'envoie dans un SMS ou une note. Au retour, coche ce que tu as acheté puis **« Ranger les articles cochés dans le stock »**.

**Le jour de cuisine.** Planning → panneau « À cuisiner cette semaine » → **Ouvrir la fiche de cuisine**. Tu y trouves tout ce qu'il faut sortir, le déroulé entrelacé des fournées, les minuteurs, et le bouton « Fournée cuisinée » qui déduit les ingrédients du stock.

**Le dimanche soir.** Training Planner → Progression : ce qui avance, ce qui stagne, le tonnage par groupe. Puis Mes performances pour les courbes détaillées.

---

## 7. Synchroniser iPhone et ordinateur

### Option A : synchronisation en ligne (fonctionne sur iPhone)

Un projet Supabase gratuit sert de boîte aux lettres entre tes appareils.

1. Crée un compte sur [supabase.com](https://supabase.com) et un nouveau projet (formule gratuite).
2. Dans le menu **SQL Editor**, colle ceci puis exécute :

```sql
create table sauvegardes (
  id text primary key,
  contenu jsonb not null,
  maj timestamptz default now()
);

alter table sauvegardes enable row level security;

create policy "acces_carnet" on sauvegardes
  for all using (true) with check (true);
```

3. Menu **Project Settings → API** : note l'**URL du projet** (`https://xxxx.supabase.co`) et la clé **anon public**.
4. Dans l'application, sur **chacun de tes appareils** : Profil → Synchronisation en ligne → **Configurer**. Renseigne l'adresse, la clé, un **nom de carnet identique partout** (par exemple `carnet-8f3a2b`), et surtout un **mot de passe de chiffrement**.

**Le mot de passe de chiffrement** protège vraiment tes données : elles sont chiffrées sur ton appareil (AES-256) avant d'être envoyées, et le serveur ne reçoit qu'un bloc illisible. Sers-toi du **même mot de passe sur chaque appareil**, et note-le quelque part : personne, pas même moi, ne peut le retrouver, et sans lui les données en ligne sont définitivement illisibles.

**L'indicateur de synchronisation** apparaît en haut de l'écran dès que la synchronisation est active : vert « À jour », jaune « En attente » ou « Envoi… », gris « Hors ligne », rose « Échec ». Un appui dessus lance une synchronisation immédiate.

À partir de là, tout est automatique : dix secondes après ta dernière modification, tes données partent en ligne ; à l'ouverture, elles reviennent. Le bouton « Synchroniser maintenant » force l'échange, typiquement en rentrant de la salle.

**Comment les conflits sont gérés.** L'application ne choisit pas un appareil contre l'autre : elle **fusionne**. Les séances saisies en salle et les courses cochées à la maison coexistent. La version la plus récente l'emporte seulement sur les éléments modifiés des deux côtés, et un message résume ce qui a été récupéré (« 2 séances récupérées, 1 pesée récupérée »).

> **À savoir sur la sécurité.** Sans mot de passe de chiffrement, la clé publique et le nom du carnet suffiraient à lire tes données. Avec le mot de passe, même quelqu'un qui obtiendrait un accès complet à la base ne verrait qu'un bloc chiffré. Garde tout de même un nom de carnet imprévisible et ne publie pas ta clé.

### Option B : fichier dans un dossier partagé (ordinateur et Android)

Profil → Fichier de sauvegarde → **Créer un fichier de sauvegarde**, en le rangeant dans ton dossier iCloud Drive ou Google Drive. Tes données s'y écrivent seules, cinq secondes après chaque modification. Sur l'autre appareil, **« Utiliser un fichier existant »** et désigne le même fichier : l'application fusionne les deux versions.

Safari sur iPhone ne permet pas cette écriture directe : sur iPhone, choisis l'option A, ou passe par l'export et l'import manuels.

---

## 8. Sauvegardes

Tes données vivent dans le navigateur. Effacer les données du site, ou désinstaller l'application, les supprime.

- **Export manuel** : Profil → **Exporter mes données**. Un fichier `.json` est téléchargé ; range-le dans iCloud ou Drive.
- **Import** : Profil → **Importer une sauvegarde**, avec trois choix : tout remplacer, **fusionner les deux versions**, ou n'ajouter que les recettes.
- **Rappel** : choisis sa fréquence (chaque semaine, quinzaine ou mois). Passé le délai, un bandeau et une notification te le rappellent au démarrage.

---

## 9. Dépannage

| Problème | Solution |
|---|---|
| Page blanche ou styles absents | Vérifie que `tailwind.css`, `chart.umd.js` et le dossier `polices` ont bien été téléversés à côté de `index.html` |
| Le bouton « Installer » n'apparaît pas | Sur iPhone, c'est normal : passe par Partager → Sur l'écran d'accueil, dans Safari |
| Les graphiques ne s'affichent pas | `chart.umd.js` est manquant ; l'application affiche alors les chiffres à la place |
| Mes données ont disparu | Réimporte ton dernier export, ou synchronise depuis l'autre appareil |
| « Synchronisation impossible » | Vérifie l'adresse (avec `https://`), la clé, le nom du carnet et la création de la table |
| Une modification n'est pas partie | Touche l'indicateur en haut de l'écran : l'envoi automatique attend dix secondes d'inactivité |
| « Mot de passe de chiffrement incorrect » | Saisis exactement le même mot de passe que sur l'autre appareil (Profil → Synchronisation → Modifier la connexion) |
| Je veux repartir de zéro | Efface les données du site dans les réglages du navigateur, après avoir exporté par sécurité |

---

## 10. Aide-mémoire des adresses

| Écran | Adresse |
|---|---|
| Accueil | `#/accueil` |
| Profil | `#/profil` |
| Planning des repas | `#/repas/planning` |
| Recettes | `#/repas/recettes` |
| Stock | `#/repas/stock` |
| Courses | `#/repas/courses` |
| Constructeur de séance | `#/entrainement/constructeur` |
| Mes séances | `#/entrainement/seances` |
| Progression | `#/entrainement/progression` |
| Mes performances | `#/entrainement/performances` |

Ces adresses fonctionnent en favori et dans les raccourcis de l'écran d'accueil.
