# Fitness & Nutrition OS — installation sur ton téléphone

L'application est maintenant une **PWA** : une fois installée, elle s'ouvre en plein écran comme une vraie application et fonctionne **sans connexion**.

## Les fichiers

| Fichier | Rôle |
|---|---|
| `index.html` | L'application (tout le code) |
| `tailwind.css` | Les styles, compilés localement |
| `chart.umd.js` | La bibliothèque de graphiques |
| `polices/` | La police Bricolage Grotesque (3 fichiers) |
| `manifest.webmanifest` | Nom, icônes, couleurs, raccourcis |
| `sw.js` | Service worker : le fonctionnement hors ligne |
| `icone-192.png`, `icone-512.png`, `icone-maskable-512.png` | Icônes de l'écran d'accueil |

Ces fichiers doivent rester **dans le même dossier**, sans être renommés, en conservant le sous-dossier `polices`.

L'application ne dépend plus d'aucun service extérieur : styles, graphiques et police sont servis depuis ton dossier. Elle fonctionne donc dès la première ouverture, même sans réseau.

## Point important

Un service worker ne fonctionne **pas** en ouvrant le fichier directement (`file://`). Il faut servir les fichiers en `https://` ou en `http://localhost`. L'application reste utilisable en double-cliquant sur `index.html`, mais sans installation ni mode hors ligne.

## Option 1 : mise en ligne gratuite avec GitHub Pages (recommandé)

1. Crée un compte sur [github.com](https://github.com), puis un dépôt, par exemple `fitness-os`.
2. Dans l'onglet **Add file → Upload files**, dépose les 6 fichiers, puis valide (*Commit changes*).
3. Va dans **Settings → Pages**, et choisis la source *Deploy from a branch*, branche `main`, dossier `/root`. Valide.
4. Au bout d'une minute, ton adresse apparaît : `https://tonpseudo.github.io/fitness-os/`.
5. Ouvre cette adresse **sur ton téléphone**, puis installe :
   - **Android (Chrome)** : une invite apparaît, ou menu ⋮ → *Installer l'application*. Le bouton « Installer sur cet appareil » de l'onglet Profil fonctionne aussi.
   - **iPhone (Safari)** : bouton Partager → *Sur l'écran d'accueil*.

Le dépôt peut être privé pour le code, mais Pages exige un dépôt public sur le forfait gratuit. Tes données, elles, ne sont jamais publiées : elles restent dans le navigateur de ton téléphone.

## Option 2 : essai local sur ordinateur

Dans le dossier des fichiers :

```bash
python3 -m http.server 8000
```

Puis ouvre `http://localhost:8000`. L'installation et le mode hors ligne sont actifs.

## Comment fonctionne le hors ligne

- À la première visite **en ligne**, le service worker met en cache la page, les icônes, ainsi que Tailwind, Chart.js et les polices.
- Ensuite, l'application démarre même sans réseau : planning, séances, stock, courses, graphiques, tout reste disponible.
- Quand tu remplaces `index.html` par une nouvelle version, l'application détecte la mise à jour et propose « Recharger » dans une notification.

## Sauvegarde automatique et synchronisation entre appareils

Dans l'onglet **Profil**, section « Fichier de sauvegarde et synchronisation » :

- **« Créer un fichier de sauvegarde »** choisit un fichier `.json` où tes données s'écrivent toutes seules, cinq secondes après chaque modification. Range ce fichier dans un dossier **Google Drive** ou **iCloud Drive** synchronisé.
- **Sur un autre appareil,** ouvre l'application, puis « Utiliser un fichier existant » et désigne le même fichier. L'application compare les horodatages : si le fichier est plus récent, elle propose de récupérer cette version ; sinon elle met le fichier à jour.
- **« Synchroniser maintenant »** force la comparaison, typiquement en rentrant de la salle.

Cette écriture directe dans un fichier fonctionne sur Chrome et Edge (ordinateur et Android). **Sur iPhone, Safari ne la propose pas** : utilise l'export manuel en enregistrant le fichier dans iCloud Drive, et l'import depuis l'autre appareil. Le rappel périodique t'y fait penser.

Un conseil pour éviter les conflits : ne saisis pas en parallèle sur deux appareils sans synchroniser entre les deux. En cas de doute, c'est toujours toi qui choisis la version à conserver.

## Chiffrement et indicateur

La synchronisation en ligne accepte un **mot de passe de chiffrement** : tes données sont chiffrées sur l'appareil avant l'envoi, et le serveur ne reçoit qu'un bloc illisible. Le même mot de passe doit être saisi sur chaque appareil.

Une pastille en haut de l'écran indique l'état : à jour, en attente, envoi en cours, hors ligne ou échec. Un appui dessus force la synchronisation.

## Rappel d'export

Toujours dans le Profil, tu choisis la fréquence du rappel (chaque semaine, tous les quinze jours, tous les mois, ou jamais). Passé ce délai sans sauvegarde, un bandeau et une notification t'alertent au démarrage.

## Sauvegarde de tes données

Tes données vivent dans le navigateur de l'appareil. Elles ne se synchronisent pas entre ton téléphone et ton ordinateur, et désinstaller l'application ou effacer les données du site les supprime.

**Réflexe à prendre :** onglet **Profil → Exporter mes données**, une fois par mois. Le fichier JSON obtenu se réimporte sur n'importe quel appareil, avec le choix entre tout remplacer et n'ajouter que les recettes.
